﻿<?php
//var_dump($_GET);

$fnName = $_GET['callbackFnName']? $_GET['callbackFnName'] : $_GET['callback']; //读取前端指定的回调函数名，如果没有指定则采用默认回调函数名
$data = $_GET['send'];
$arr = array('status'=>1,'info'=>'这是返回的jsonp数据：“'.$data.'”');

echo $fnName.'('.json_encode($arr).')'; //返回jsonp格式的数据